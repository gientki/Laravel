# Laravel Petstore REST API Client

Aplikacja Laravel do obsługi REST API z [Swagger Petstore](https://petstore.swagger.io/).

## 🔧 Funkcje

- Dodawanie zwierzaków (`POST /pet`)
- Przeglądanie listy (`GET /pet`)
- Podgląd pojedynczego zwierzaka (`GET /pet/{id}`)
- Edycja zwierzaka (`PUT /pet/{id}`)
- Usuwanie (`DELETE /pet/{id}`)
- Obsługa błędów
- Przejrzysty interfejs z formularzami (Blade)

## 🚀 Instalacja

```bash
git clone https://github.com/NAZWA_UZYTKOWNIKA/NazwaRepo.git
cd laraver-petstore
composer install
cp .env.example .env
php artisan key:generate
